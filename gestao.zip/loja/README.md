# Loja

Projeto de exemplo de _Loja Online_ ilustrando o uso do Spring boot.

## Membros da Equipe

- Aluno 1
- Aluno 2

## API Implementada

API para controle do cadastro dos produtos que serão vendidos na loja.

