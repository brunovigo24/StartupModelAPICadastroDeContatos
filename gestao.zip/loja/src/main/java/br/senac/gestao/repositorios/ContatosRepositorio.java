package br.senac.gestao.repositorios;

import br.senac.gestao.entidades.Contatos;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ContatosRepositorio extends JpaRepository<Contatos, Long> {

        List<Contatos> searchByNome(String nome);

        Contatos findByNome(String nome);
}
